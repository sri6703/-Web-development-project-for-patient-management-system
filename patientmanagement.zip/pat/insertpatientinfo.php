
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Insert Data in patient_info table </title>
</head>
<style>
  input[type=text], select {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 70%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
    width: 40%;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}
</style>
<body>
    <center>
        <h1>Insert Data in patient_info table </h1>
<div>
        <form action="insertpatientinfophp.php" method="post">
       
            <p>
                <label for="aadhar_no">aadhar_no:</label>
                <input type="text" name="aadhar_no" id="aadhar_no">
            </p>

            <p>
                <label for="DOB">DOB:</label>
                <input type="text" name="DOB" id="DOB">
            </p>

            <p>
                <label for="patient_name">patient_name:</label>
                <input type="text" name="patient_name" id="patient_name">
            </p>

            <p>
                <label for="gender">gender:</label>
                <input type="text" name="gender" id="gender">
            </p>

            <p>
                <label for="pin_code">pin_code:</label>
                <input type="text" name="pin_code" id="pin_code">
            </p>

            <p>
                <label for="street_name">street_name:</label>
                <input type="text" name="street_name" id="street_name">
            </p>

            <p>
                <label for="door_no">door_no:</label>
                <input type="text" name="door_no" id="door_no">
            </p>

            <p>
                <label for="city_name">city_name:</label>
                <input type="text" name="city_name" id="city_name">
            </p>

            <input type="submit" value="Submit">
        </form>
</div>
    </center>
</body>

</html>