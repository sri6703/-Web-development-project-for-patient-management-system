
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Insert Data in prescription table </title>
</head>
<style>
  input[type=text], select {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 70%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
    width: 40%;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}
</style>
<body>
    <center>
        <h1>Insert Data in prescription table</h1>
<div>
        <form action="insertprescphp.php" method="post">


            <p>
                <label for="prescription_no">prescription_no:</label>
                <input type="text" name="prescription_no" id="prescription_no">
            </p>

            <p>
                <label for="patient_id">patient_id:</label>
                <input type="text" name="patient_id" id="patient_id">
            </p>

            <p>
                <label for="no_of_tablets">no_of_tablets:</label>
                <input type="text" name="no_of_tablets" id="no_of_tablets">
            </p>

            <p>
                <label for="Address">no_of_tonics:</label>
                <input type="text" name="no_of_tonics" id="no_of_tonics">
            </p>

            <p>
                <label for="doctor_id">doctor_id:</label>
                <input type="text" name="doctor_id" id="doctor_id">
            </p>

            <input type="submit" value="Submit">
        </form>
</div>
    </center>
</body>

</html>