
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Insert Data in user table </title>
</head>
<style>
  input[type=text], select {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 70%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
    width: 40%;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}
</style>
<body>
    <center>
        <h1>Insert Data in user table </h1>
<div>
        <form action="insertuserphp.php" method="post">


            <p>
                <label for="uid">user_id:</label>
                <input type="text" name="uid" id="uid">
            </p>

            <p>
                <label for="user_name">user_name:</label>
                <input type="text" name="user_name" id="user_name">
            </p>

            <p>
                <label for="password">password:</label>
                <input type="text" name="password" id="password">
            </p>

            <p>
                <label for="user_email">user_email:</label>
                <input type="text" name="user_email" id="user_email">
            </p>

            <p>
                <label for="phone_no">phone_no:</label>
                <input type="text" name="phone_no" id="phone_no">
            </p>
            <p>
                <label for="dob">dob:</label>
                <input type="text" name="dob" id="dob">
            </p>
            <p>
                <label for="gender">gender:</label>
                <input type="text" name="gender" id="gender">
            </p>
            <p>
                <label for="address">address:</label>
                <input type="text" name="address" id="address">
            </p>

            <input type="submit" value="Submit">
        </form>
</div>
    </center>
</body>

</html>