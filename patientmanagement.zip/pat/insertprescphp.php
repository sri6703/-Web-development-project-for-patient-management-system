<!DOCTYPE html>
<html>

<head>
	<title>Insert Prescription </title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "patient_management");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$prescription_no = $_POST['prescription_no'];
$patient_id = $_POST['patient_id'];
$no_of_tablets = $_POST['no_of_tablets'];
$no_of_tonics = $_POST['no_of_tonics'];
$doctor_id = $_POST['doctor_id'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO prescription VALUES ('$prescription_no',
			'$no_of_tablets','$no_of_tonics','$doctor_id','$patient_id')";
		
        
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in the database successfully."
				. " </h3>";

			echo nl2br("\n$prescription_no\n $patient_id\n "
				. "$no_of_tablets\n $no_of_tonics\n $doctor_id");
		} 
        else {
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>