<!DOCTYPE html>
<html>

<head>
	<title>Insert User </title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "patient_management");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
$uid = $_POST['uid'];                                 
$user_name = $_POST['user_name'];
$password = $_POST['password'];
$user_email = $_POST['user_email'];
$phone_no = $_POST['phone_no'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];
$address = $_POST['address'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO user_ VALUES ('$uid',
			'$user_name','$password','$user_email','$phone_no','$dob','$gender','$address')";
		
        
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in the database successfully."
				. " </h3>";

			echo nl2br("\n$uid\n $user_name\n "
				. "$password\n $user_email\n $phone_no\n $dob\n $gender\n $address");
		} 
        else {
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>