<!DOCTYPE html>
<html>

<head>
	<title>Insert Patent info </title>
</head>

<body>
	<center>
		<?php

		
		$conn = mysqli_connect("localhost", "root", "", "patient_management");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		$aadhar_no = $_POST['aadhar_no'];
$DOB = $_POST['DOB'];
$patient_name = $_POST['patient_name'];
$gender = $_POST['gender'];
$pin_code = $_POST['pin_code'];
$street_name = $_POST['street_name'];
$door_no = $_POST['door_no'];
$city_name = $_POST['city_name'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO patient_info VALUES ('$aadhar_no',
			'$DOB','$patient_name','$gender','$pin_code','$street_name','$door_no','$city_name')";
		
        
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in the database successfully."
				. " </h3>";

			echo nl2br("\n$aadhar_no\n $DOB\n "
				. "$patient_name\n $gender\n $pin_code\n $street_name\n $door_no\n $city_name");
		} 
        else {
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>